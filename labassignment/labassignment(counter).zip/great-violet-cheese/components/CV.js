// CVScreen.js

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const CVScreen = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>My CV Details</Text>
      {/* Add your CV details here */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
});

export default CVScreen;
