import React, { useState } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const App = () => {
  const [value, setValue] = useState(0);

  const handleAdd = () => {
    setValue(value + 1);
  };

  const handleMinus = () => {
    setValue(value - 1);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.valueText}>Value: {value}</Text>
      <Button title="Add" onPress={handleAdd} />
      <Button title="Minus" onPress={handleMinus} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  valueText: {
    fontSize: 24,
    marginBottom: 20,
  },
});

export default App;






